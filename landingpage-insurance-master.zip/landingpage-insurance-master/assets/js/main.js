// Burger
$('.burger').on('click', function(event){
  $('.navigation-bar').slideToggle('200');
})